package associazioneVolontariatoSanitario.Volontariato.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Ruolo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer idRuolo;
	
	@Column(length = 30, nullable=false, unique=true)
	private String Ruolo;
	
	@JsonManagedReference
	@OneToMany(mappedBy = "ruolo", cascade = CascadeType.ALL)
	private List<Volontario> volontari = new ArrayList<Volontario>();

	public Integer getIdRuolo() {
		return idRuolo;
	}

	public void setIdRuolo(Integer idRuolo) {
		this.idRuolo = idRuolo;
	}

	public String getRuolo() {
		return Ruolo;
	}

	public void setRuolo(String ruolo) {
		Ruolo = ruolo;
	}

	public List<Volontario> getVolontari() {
		return volontari;
	}

	public void setVolontari(List<Volontario> volontari) {
		this.volontari = volontari;
	}

	public Ruolo(Integer idRuolo, String ruolo, List<Volontario> volontari) {
		super();
		this.idRuolo = idRuolo;
		Ruolo = ruolo;
		this.volontari = volontari;
	}

	public Ruolo() {
		super();
	}

	public Ruolo(Integer idRuolo, String ruolo) {
		super();
		this.idRuolo = idRuolo;
		Ruolo = ruolo;
	}

	@Override
	public String toString() {
		return "Ruolo [idRuolo=" + idRuolo + ", Ruolo=" + Ruolo + ", volontari=" + volontari + "]";
	}

	
}
