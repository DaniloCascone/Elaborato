package associazioneVolontariatoSanitario.Volontariato.model;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Equipaggio {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer idEquipaggio;
	
	@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "codiceIntervento", insertable = false, updatable = false)
	 private Intervento intervento; // variabile della tabella di arrivo 
	
	@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "codiceVolontario", insertable = false, updatable = false)
	 private Volontario volontario; // variabile della tabella di arrivo 

	public Integer getIdEquipaggio() {
		return idEquipaggio;
	}

	public void setIdEquipaggio(Integer idEquipaggio) {
		this.idEquipaggio = this.intervento.getIdIntervento()+this.volontario.getIdVolontario();
	}

	public Intervento getIntervento() {
		return intervento;
	}

	public void setIntervento(Intervento intervento) {
		this.intervento = intervento;
	}

	public Volontario getVolontario() {
		return volontario;
	}

	public void setVolontario(Volontario volontario) {
		this.volontario = volontario;
	}
	
	

	public Equipaggio(Intervento intervento, Volontario volontario) {
		super();
		this.intervento = intervento;
		this.volontario = volontario;
	}
	
	public Equipaggio() {
		super();
		
	}

	@Override
	public String toString() {
		return "Equipaggio [intervento=" + intervento + ", volontario=" + volontario + "]";
	}
	
	

}
