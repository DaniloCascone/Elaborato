package associazioneVolontariatoSanitario.Volontariato.model;


import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Intervento {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer idIntervento;
	
	@Column
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date dataIntervento;
	
	@Column
	@DateTimeFormat(pattern = "HH:mm:ss")
	private Time durata; //modificare in datetime
	
	@Column
	private Integer chilometriPercorsi;
	
	@Column
	@DateTimeFormat(pattern = "HH:mm")
	private Time oraPartenza; //modificare in datetime
	
	@Column
	@DateTimeFormat(pattern = "HH:mm")
	private Time oraArrivo; //modificare in datetime
	
	@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "codiceAmbulanza", insertable = false, updatable = false)
	 private Ambulanza ambulanza; // variabile della tabella di arrivo 
	
	@JsonManagedReference
	@OneToMany(mappedBy = "intervento", cascade = CascadeType.ALL)
	private List<Equipaggio> equipaggio = new ArrayList<Equipaggio>();

	public Integer getIdIntervento() {
		return idIntervento;
	}

	public void setIdIntervento(Integer idIntervento) {
		this.idIntervento = idIntervento;
	}

	public Date getDataIntervento() {
		return dataIntervento;
	}

	public Intervento(Date dataIntervento, Time durata, Integer chilometriPercorsi, Time oraPartenza, Time oraArrivo) {
		super();
		this.dataIntervento = dataIntervento;
		this.durata = durata;
		this.chilometriPercorsi = chilometriPercorsi;
		this.oraPartenza = oraPartenza;
		this.oraArrivo = oraArrivo;
	}

	public void setDataIntervento(Date dataIntervento) {
		this.dataIntervento = dataIntervento;
	}

	public Time getDurata() {
		return durata;
	}

	public void setDurata(Time durata) {
		this.durata = durata;
	}

	public Integer getChilometriPercorsi() {
		return chilometriPercorsi;
	}

	public void setChilometriPercorsi(Integer chilometriPercorsi) {
		this.chilometriPercorsi = chilometriPercorsi;
	}

	public Time getOraPartenza() {
		return oraPartenza;
	}

	public void setOraPartenza(Time oraPartenza) {
		this.oraPartenza = oraPartenza;
	}

	public Time getOraArrivo() {
		return oraArrivo;
	}

	public void setOraArrivo(Time oraArrivo) {
		this.oraArrivo = oraArrivo;
	}

	public Ambulanza getAmbulanza() {
		return ambulanza;
	}

	public void setAmbulanza(Ambulanza ambulanza) {
		this.ambulanza = ambulanza;
	}

	public List<Equipaggio> getEquipaggio() {
		return equipaggio;
	}

	public void setEquipaggio(List<Equipaggio> equipaggio) {
		this.equipaggio = equipaggio;
	}

	public Intervento(Integer idIntervento, Date dataIntervento, Time durata, Integer chilometriPercorsi,
			Time oraPartenza, Time oraArrivo, Ambulanza ambulanza, List<Equipaggio> equipaggio) {
		super();
		this.idIntervento = idIntervento;
		this.dataIntervento = dataIntervento;
		this.durata = durata;
		this.chilometriPercorsi = chilometriPercorsi;
		this.oraPartenza = oraPartenza;
		this.oraArrivo = oraArrivo;
		this.ambulanza = ambulanza;
		this.equipaggio = equipaggio;
	}

	public Intervento() {
		super();
		
	}

	@Override
	public String toString() {
		return "Intervento [idIntervento=" + idIntervento + ", dataIntervento=" + dataIntervento + ", durata=" + durata
				+ ", chilometriPercorsi=" + chilometriPercorsi + ", oraPartenza=" + oraPartenza + ", oraArrivo="
				+ oraArrivo + ", ambulanza=" + ambulanza + ", equipaggio=" + equipaggio + "]";
	}
	
	
	
	
	

}
