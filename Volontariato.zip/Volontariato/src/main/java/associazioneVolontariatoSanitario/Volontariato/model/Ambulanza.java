package associazioneVolontariatoSanitario.Volontariato.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonManagedReference;


@Entity
public class Ambulanza {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer idAmbulanza;
	
	@Column
	private boolean unitaDiRianimazione;
	
	@Column
	private boolean disponibilita;
	
	@JsonManagedReference
	@OneToMany(mappedBy = "ambulanza", cascade = CascadeType.ALL)
	private List<Intervento> interventi = new ArrayList<Intervento>();

	public Integer getIdAmbulanza() {
		return idAmbulanza;
	}

	public void setIdAmbulanza(Integer idAmbulanza) {
		this.idAmbulanza = idAmbulanza;
	}

	public boolean isUnitaDiRianimazione() {
		return unitaDiRianimazione;
	}

	public void setUnitaDiRianimazione(boolean unitaDiRianimazione) {
		this.unitaDiRianimazione = unitaDiRianimazione;
	}

	public boolean isDisponibilita() {
		return disponibilita;
	}

	public void setDisponibilita(boolean disponibilita) {
		this.disponibilita = disponibilita;
	}

	public List<Intervento> getInterventi() {
		return interventi;
	}

	public void setInterventi(List<Intervento> interventi) {
		this.interventi = interventi;
	}

	public Ambulanza(Integer idAmbulanza, boolean unitaDiRianimazione, boolean disponibilita,
			List<Intervento> interventi) {
		super();
		this.idAmbulanza = idAmbulanza;
		this.unitaDiRianimazione = unitaDiRianimazione;
		this.disponibilita = disponibilita;
		this.interventi = interventi;
	}

	public Ambulanza() {
		super();
	}
	
	

	public Ambulanza(boolean unitaDiRianimazione, boolean disponibilita) {
		super();
		this.unitaDiRianimazione = unitaDiRianimazione;
		this.disponibilita = disponibilita;
	}

	@Override
	public String toString() {
		return "Ambulanza [idAmbulanza=" + idAmbulanza + ", unitaDiRianimazione=" + unitaDiRianimazione
				+ ", disponibilita=" + disponibilita + ", interventi=" + interventi + "]";
	}
 
	
	
}
