package associazioneVolontariatoSanitario.Volontariato.model;

import java.sql.Date;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonBackReference;



@Entity
public class Volontario {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer idVolontario;
	
	@Column(length = 30,nullable = false)
	private String nome;
	
	@Column(length = 30,nullable = false)
	private String cognome;
	
	@Column(nullable=false)
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date dataDiNascita;
	
	@Column(length = 15, nullable=false)
	private String telefono;
	
	@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "codiceRuolo" )
	 private Ruolo ruolo; // variabile della tabella di arrivo 

	public Integer getIdVolontario() {
		return idVolontario;
	}

	public void setIdVolontario(Integer idVolontario) {
		this.idVolontario = idVolontario;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public Date getDataDiNascita() {
		return dataDiNascita;
	}

	public void setDataDiNascita(Date dataDiNascita) {
		this.dataDiNascita = dataDiNascita;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public Ruolo getRuolo() {
		return ruolo;
	}

	public void setRuolo(Ruolo ruolo) {
		this.ruolo = ruolo;
	}

	public Volontario(Integer idVolontario, String nome, String cognome, Date dataDiNascita, String telefono,
			Ruolo ruolo) {
		super();
		this.idVolontario = idVolontario;
		this.nome = nome;
		this.cognome = cognome;
		this.dataDiNascita = dataDiNascita;
		this.telefono = telefono;
		this.ruolo = ruolo;
	}

	public Volontario() {
		super();
	}

	@Override
	public String toString() {
		return "Volontario [idVolontario=" + idVolontario + ", nome=" + nome + ", cognome=" + cognome
				+ ", dataDiNascita=" + dataDiNascita + ", telefono=" + telefono + ", ruolo=" + ruolo + "]";
	}
	
	
}
