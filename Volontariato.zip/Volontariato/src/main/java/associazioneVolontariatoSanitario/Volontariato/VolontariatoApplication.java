package associazioneVolontariatoSanitario.Volontariato;

import java.util.stream.Stream;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import associazioneVolontariatoSanitario.Volontariato.model.Ambulanza;
import associazioneVolontariatoSanitario.Volontariato.model.Ruolo;
import associazioneVolontariatoSanitario.Volontariato.repository.AmbulanzaRepository;
import associazioneVolontariatoSanitario.Volontariato.repository.RuoloRepository;

@SpringBootApplication
public class VolontariatoApplication {

	public static void main(String[] args) {
		SpringApplication.run(VolontariatoApplication.class, args);
	}
	
	@Bean //deve succedere prima del controller, appena viene eseguito il server
    CommandLineRunner init(RuoloRepository ruoloRepository, AmbulanzaRepository ambulanzaRepository) {
        return args -> {
            Stream.of("Autista", "Leader", "Volontario").forEach(name -> {
                
                Ruolo a = new Ruolo(0,name);
                ruoloRepository.save(a);
                
            });
            Stream.of(false,true,false,true,false,true,false,true,false,true).forEach(name -> {
                
                Ambulanza b = new Ambulanza(name,name);
                ambulanzaRepository.save(b);
        });
            

};
}
	
	/*@Bean //deve succedere prima del controller, appena viene eseguito il server
    CommandLineRunner init(AmbulanzaRepository ambulanzaRepository) {
        return args -> {
            Stream.of(false,true,false).forEach(name -> {
                
                Ambulanza b = new Ambulanza(name,name);
                ambulanzaRepository.save(b);
                
            });
        };

}*/
	
}
