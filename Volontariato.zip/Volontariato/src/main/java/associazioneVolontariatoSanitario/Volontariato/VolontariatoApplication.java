package associazioneVolontariatoSanitario.Volontariato;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VolontariatoApplication {

	public static void main(String[] args) {
		SpringApplication.run(VolontariatoApplication.class, args);
	}

}
