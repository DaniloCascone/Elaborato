package associazioneVolontariatoSanitario.Volontariato.controller;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDateTime;
import java.time.LocalTime;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import associazioneVolontariatoSanitario.Volontariato.model.Ambulanza;
import associazioneVolontariatoSanitario.Volontariato.model.Intervento;
import associazioneVolontariatoSanitario.Volontariato.model.Ruolo;
import associazioneVolontariatoSanitario.Volontariato.model.Volontario;
import associazioneVolontariatoSanitario.Volontariato.repository.*;


@Controller
public class WebController {
	@Autowired
	AmbulanzaRepository ambulanzaRepository;
	@Autowired
	EquipaggioRepository equipaggioRepository;
	@Autowired
	InterventoRepository interventoRepository;
	@Autowired
	RuoloRepository ruoloRepository;
	@Autowired
	VolontarioRepository volontarioRepository;
	



	private HttpSession session;

	
	public HttpSession getSession() {
		return session;
	}
	public void setSession(HttpSession session) {
		this.session = session;
	}

	@RequestMapping(value = "/")
	public String index(){
		return "index";
	}
	
	@RequestMapping(value = "/page")
	public String page(){
		return "page";
	}
	
	@RequestMapping(value = "/intervento")
	public String intervento(){
		return "intervento";
	}
	
	

	@RequestMapping(value = "/errorpage")
	public String errorpage() {
		return "errorpage";
	}	
	
	@RequestMapping(value = "/aggiungivolontario")
	public String inserimentoVolontario(
		@RequestParam(name = "nome",  required = false) String nome,
		@RequestParam(name = "cognome", required = false) String cognome,
		@RequestParam(name = "datadinascita", required = false) Date datadinascita,
		@RequestParam(name = "telefono", required = false) String telefono,
		@RequestParam(name = "ruolo", required = false) Integer ruolo

		) {	
		Volontario volontario = new Volontario();
		volontario.setNome(nome);
		volontario.setCognome(cognome);
		volontario.setDataDiNascita(datadinascita);
		volontario.setTelefono(telefono);
		volontario.setRuolo(ruoloRepository.getOne(ruolo));
		volontarioRepository.save(volontario);
		return "index";
		
	
	}
	
	
	@RequestMapping(value = "/cambiaunita")
	public String page(
			@RequestParam("idAmbulanza") Integer idAmbulanza
			) {
		Ambulanza ambulanza = ambulanzaRepository.getOne(idAmbulanza);
		if(ambulanza.isUnitaDiRianimazione()) {
			ambulanza.setUnitaDiRianimazione(false);
		}
		else{
			ambulanza.setUnitaDiRianimazione(true);

		}
		ambulanzaRepository.save(ambulanza);
			
		return "page";
	}
	
	@RequestMapping(value = "/cambiadisponibilita")
	public String cambiadisponibilita(
			@RequestParam("idAmbulanza") Integer idAmbulanza
			) {
		Ambulanza ambulanza = ambulanzaRepository.getOne(idAmbulanza);
		if(ambulanza.isDisponibilita()) {
			ambulanza.setDisponibilita(false);
		}
		else {
			ambulanza.setDisponibilita(true);

		}
		ambulanzaRepository.save(ambulanza);
			
		return "page";
	}
	
	@RequestMapping(value = "/inserireintervento")
	public String inserimentoIntervento(
		@RequestParam(name = "idambulanza",  required = false) Integer idambulanza,
		@RequestParam(name = "dataintervento",  required = false) Date dataintervento,
		@RequestParam(name = "durata" ) String durata,
		@RequestParam(name = "chilometripercorsi") Integer chilometripercorsi,
		@RequestParam(name = "orapartenza", required = false) String orapartenza,
		@RequestParam(name = "oraarrivo", required = false) String oraarrivo

		) {	
		Intervento intervento = new Intervento();
		Ambulanza ambulanza = ambulanzaRepository.getOne(idambulanza);
		intervento.setChilometriPercorsi(chilometripercorsi);
		intervento.setDataIntervento(dataintervento);
		intervento.setDurata(durata);
		intervento.setOraPartenza(orapartenza);
		intervento.setOraArrivo(oraarrivo);
		intervento.setAmbulanza(ambulanza);
		
		interventoRepository.save(intervento);
		return "intervento";
		
	
	}
	
	
	
	
	
	@ModelAttribute
    public void ruoli(Model model) {
        model.addAttribute("ruolo", ruoloRepository.findAll());
        model.addAttribute("ambulanza", ambulanzaRepository.findAll());
        model.addAttribute("intervento", interventoRepository.findAll());
    }
	
	

}
