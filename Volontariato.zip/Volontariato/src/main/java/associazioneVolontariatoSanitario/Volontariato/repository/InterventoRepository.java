package associazioneVolontariatoSanitario.Volontariato.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import associazioneVolontariatoSanitario.Volontariato.model.Intervento;

@Repository
public interface InterventoRepository extends JpaRepository<Intervento, Integer>  {

}
