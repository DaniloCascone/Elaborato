package associazioneVolontariatoSanitario.Volontariato.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import associazioneVolontariatoSanitario.Volontariato.model.Ruolo;

@Repository
public interface RuoloRepository extends JpaRepository<Ruolo, Integer>  {

}
