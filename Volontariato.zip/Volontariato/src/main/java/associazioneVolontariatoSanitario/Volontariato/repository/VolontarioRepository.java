package associazioneVolontariatoSanitario.Volontariato.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import associazioneVolontariatoSanitario.Volontariato.model.Volontario;


@Repository
public interface VolontarioRepository extends JpaRepository<Volontario, Integer> {
	

}
